"""
Enunciado

Una empresa de arriendo de maquinaria necesita un sistema que calcule el costo total del servicio.

El programa debe solicitar:

    Nombre del cliente (mínimo 3 caracteres)
    Teléfono (8 a 9 dígitos)
    Horas de trabajo
    Tipo de equipo
    Cantidad de horas por equipo

Equipos disponibles:

   Equipo

Precio por hora

    Excavadora $200.000
    Grúa  $250.000
    Mezcladora $150.000
    
El sistema debe:

    Validar datos de entrada
    Permitir seleccionar al menos 1 equipo
    Calcular el total

Salida esperada:

Mostrar:

    Nombre
    Teléfono
    Total, de horas
    Detalle de equipos
    Precio total
    
    """