"""
Una tienda de retail necesita un programa que permita calcular el descuento aplicado a una compra.

El sistema debe:

Solicitar:

    Nombre del cliente (mínimo 3 caracteres)
    Monto de la compra (número entero positivo)

Validaciones:

    Nombre válido
    Monto mayor o igual a 0

Reglas de negocio:

   Monto 
   
   Descuento < 10.000 = 0%

  10.000 - 50.000 = 10%
  
  > 50.000 = 20%
  
"""

# Mensaje de bienvenida;

print("*****Bienvenido a Paris*****");  


# Solicitud de nombre y monto de compra;

nombreCliente = str(input("Escriba su nombre: "));  

nombreCaracteres = len(nombreCliente); 

if nombreCaracteres > 3 or type != int:
  
    montoCliente = int(input("Digite el monto de compra: ")); 
  
    if montoCliente >= 0:
      
      if montoCliente < 10000:
        
        descuento = 0
        
        montoFinal = montoCliente
        
        montoFinalCliente = montoCliente
        
        print("Usted no aplica para el descuento"); 
        
        print("*****Boleta*****"); 
         
        print(f"{nombreCliente}");  
        
        print(f"{descuento} %");  
          
        print(f"Total a pagar: {montoFinalCliente}"); 
        
      if montoCliente >= 10000 or montoCliente <= 50000:
        
        descuento = 10
        
        montoFinalDescuento = montoCliente  / descuento
        
        montoFinalCliente = montoCliente - montoFinalDescuento
        
        print(f"Usted aplica para un descuento de :{descuento}% "); 
        
        print("*****Boleta*****"); 
         
        print(f"{nombreCliente}");  
        
        print(f"Descuento Aplicado: {descuento} %");  
          
        print(f"Total a pagar: {montoFinalCliente}"); 
        
      
      if montoCliente > 50000:
        
        descuento = 20
        
        montoFinalDescuento = montoCliente / descuento
        
        montoFinalCliente = montoCliente - montoFinalDescuento
        
        print(f"Usted aplica para un descuento de :{descuento}% "); 
        
        print("*****Boleta*****"); 
         
        print(f"{nombreCliente}");  
        
        print(f"{descuento} %");  
          
        print(f"Total a pagar: {montoFinalDescuento}");  
           
else:
  
  print("¡ERROR! Su nombre debe tener minimo 3 caracteres alfabeticos"); 
  
# Hora de termino 9:58 