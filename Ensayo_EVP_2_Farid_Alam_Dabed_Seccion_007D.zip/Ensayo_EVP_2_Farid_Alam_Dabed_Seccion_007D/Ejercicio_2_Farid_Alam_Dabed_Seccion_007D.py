# Importamos la libreria; 

import random;

# Definimos vidas de usuario; 

vidasUsuario = 3;

# Definimos rango de numeros; 

numeroRandom = random.randint(1, 10)

# Bucle

while vidasUsuario > 0:

  # Definimos numero usuario;

  numeroUsuario = int(input("Por, favor selecciona un numero entre 1-10: ")); 

  # Si la condicion se cumple haz esto;

  if numeroRandom == numeroUsuario:

    print(f"Felicidades, tu numero: {numeroUsuario} es el numero correcto: {numeroRandom}"); 

    # Se pone fin al bucle en caso de que se cumpla la condicion; 

    break;  

  # Si no se cumple la condicion haz esto;  
  
  else:  

    vidasUsuario -= 1; 
  
    print("El numero seleccionado no es el correcto, intentalo nuevamente");  

    print(f"Te quedan: {vidasUsuario} vidas")  

    # Si se acaban las vidas de el usuario haz lo siguiente;  
  
    if vidasUsuario == 0:

      print(f"Has perdido todas las vidas, el numero random era {numeroRandom}"); 
