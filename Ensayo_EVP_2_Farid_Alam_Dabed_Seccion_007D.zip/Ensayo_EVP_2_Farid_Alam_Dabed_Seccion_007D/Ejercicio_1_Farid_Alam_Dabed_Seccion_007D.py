# Definimos los valores base; 

mensualidad_Moto = 15000; 

arriendo_Candado = 9000;  

# Intenta lo siguiente; 

try:

  # Mensaje de plataforma de cobro; 

  print("***** Sistema de Cobro Centro Civico *****"); 

  # Solicitamos Variables de entrada; 

  cantidad_UsoDiasxMes = int(input("Por, favor digite la cantidad de dias al mes que usara el servicio: ")); 

  condicion_Estudiante = str(input("¿Es usted estudiante? (Si/No): "));  

  medio_Pago = str(input("¿Pagara con Tarjeta? (Si/No): ")); 

  descuento_Moto = 1; 

  # Si no se cumple la condicion haz lo siguiente;

  if condicion_Estudiante == "No":

    # Si supera x cantidad de dias haz lo siguiente;  

    if cantidad_UsoDiasxMes >= 20:

      # Mensaje de aviso y aplicacion descuento;  

      descuento_Moto = 0.92; 

      print("Se le a aplicado un 8% de descuento"); 

  
  # De lo contrario haz lo siguiente; 

  else:

    if cantidad_UsoDiasxMes >= 20:

      # Mensaje de aviso y aplicacion descuento;

      descuento_Moto = 0.75;  

      print("Querido estudiante, debido a tu condicion se aplicara un 25% de descuento"); 

    else:

     # Mensaje de aviso y aplicacion descuento; 

      descuento_Moto = 0.85;  

      print("Querido estudiante, debido a tu condicion se aplicara un 15% de descuento"); 
  
  # Se hace el calculo de la moto;

  calculoTotal_Moto = cantidad_UsoDiasxMes * mensualidad_Moto * descuento_Moto; 

  # Solicitamos Variables de entrada para candado; 

  cantidad_UsoDiasxMesCandado = int(input("Por, favor digite la cantidad de dias al mes que usara el servicio de candado: "));  

  if cantidad_UsoDiasxMesCandado < 10:

    # Mensaje de aviso que no hay descuento;

    descuento_Candado = 1; 

    cantidad_Total = calculoTotal_Moto + (cantidad_UsoDiasxMesCandado * arriendo_Candado);  

    print("Usted no a obtenido descuento"); 

  elif cantidad_UsoDiasxMesCandado >= 10 and cantidad_UsoDiasxMesCandado <= 14:

    # Mensaje de aviso y aplicacion descuento;
      
    descuento_Candado = 0.95;  

    cantidad_Total = calculoTotal_Moto + (cantidad_UsoDiasxMesCandado * arriendo_Candado * descuento_Candado); 

    print("Usted a obtenido 5% de descuento")

  if condicion_Estudiante == "Si" and medio_Pago == "Si" and cantidad_UsoDiasxMesCandado >= 15:

    # Mensaje de aviso condicion estudiante, pago con tarjeta y cantidad de dias, aplicacion descuento; 

    descuento_Candado = 0.88; 

    cantidad_Total = calculoTotal_Moto + (cantidad_UsoDiasxMesCandado * arriendo_Candado * descuento_Candado); 

    print("Querido estudiante debido a tu condicion y metodo de pago haz recibido un 12% de descuento en el total"); 

  print("*****RESUMEN DE SERVICIO*****"); 

  print(f" Sus dias de uso fueron: {cantidad_UsoDiasxMes}"); 

  print(f" Sus dias de uso de el candado fueron: {cantidad_UsoDiasxMesCandado}"); 

  print(f" Su total a pagar fue de: {cantidad_Total}"); 

  print("*****MUCHAS GRACIAS POR PREFERIRNOS*****");  

except ValueError:

  print("¡ERROR!, favor intente nuevamente"); 