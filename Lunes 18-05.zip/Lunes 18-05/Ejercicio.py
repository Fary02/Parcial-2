# Creacion de menu;

try:
  
  while True:
  
    def calculo_Promedio(notas, cantidad):
    
      return notas / cantidad; 

  # Mensaje inicial;  

    print("\n******Bienvenido a DuocUC Docente******"); 
  
    print("\nAsignaturas disponibles:"); 
  
    print("\n1- Nivelacion matematica"); 
    print("2- Fundamentos de programacion"); 
    print("3- Devops");  
    print("4- IA"); 
    print("5- Ciencia de datos"); 
    print("6- Consultar Nota");  
    print("7- Salir");  
   
   # Seleccion de asignatura

    opcion_Asignatura = int(input("\n Selecciona una opcion: ")); 
  
    if opcion_Asignatura == 1:
    
      nota = float(input("Ingresa la nota de Nivelacion matematica: "));  
    
    elif opcion_Asignatura == 2:
    
      nota = float(input("Ingresa la nota de Fundamentos de programacion: ")); 
    
    elif opcion_Asignatura == 3:
    
      nota = float(input("Ingresa la nota de Devops: ")); 
    
    elif opcion_Asignatura == 4:
    
      nota = float(input("Ingresa la nota de IA: ")); 
    
    elif opcion_Asignatura == 5:
    
      nota = float(input("Ingresa la nota de Ciencia de datos: ")); 
    
    elif opcion_Asignatura == 6:
    
      opcion_Asignatura = int(input("Selecciona la asignatura a consultar: "));  
      
      while True: 
    
        if opcion_Asignatura == 1:
      
          print(f"La nota de Nivelacion matematica es: "); 
    
        else: print("Debes ingresar la nota primero"); 
      
    elif opcion_Asignatura == 7:
      
      print("¡Adios, que tenga buena jornada!")
      
      break;  
      
   


    
    
    
# Mensaje de error en caso de elegir una opcion invalida;  
  
except ValueError: print("¡ERRROR!, selecciona una opcion valida"); 