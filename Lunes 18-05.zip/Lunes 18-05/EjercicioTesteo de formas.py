for i in range (1):
  
  while True:
    
    try:
      
      def calculo_Promedio(notas, cantidad):
    
        return notas / cantidad; 

  # Mensaje inicial;  

      print("\n******Bienvenido a DuocUC Docente******"); 
      
      # Aca se puede pedir ingresar la nota, para que se pueda consultar mas adelante
      
      notaM = float(input("Ingresa la nota de Nivelacion matematica: ")); 
      notaF = float(input("Ingresa la nota de Fundamentos de programacion: ")); 
      NotaD = float(input("Ingresa la nota de Devops: "));  
      notaIA = float(input("Ingresa la nota de IA: ")); 
      notaC = float(input("Ingresa la nota de Ciencia de datos: ")); 
  
      print("\nAsignaturas disponibles:"); 
  
      print("\n1- Nivelacion matematica"); 
      print("2- Fundamentos de programacion"); 
      print("3- Devops");  
      print("4- IA"); 
      print("5- Ciencia de datos"); 
      print("*****Opciones*****") 
      print("6- Consultar Nota");  
      print("7- Salir");  
   
   # Seleccion de asignatura

      opcion_Asignatura = int(input("\n Selecciona una opcion: ")); 
  
      if opcion_Asignatura == 6:
    
        opcion_Asignatura = int(input("Selecciona la asignatura a consultar: "));  
      
        for i in range (1):
  
        # while True: Si se descomenta se repite eternamente 
    
            if opcion_Asignatura == 1:
      
              print(f"La nota de Nivelacion matematica es: {notaM}");  
              
            elif opcion_Asignatura == 2:
              
              print(f"La nota de Fundamentos de programacion es: {notaF}");  
              
            elif opcion_Asignatura == 3:
              
              print(f"La nota de Devops es: {NotaD}");  
              
            elif opcion_Asignatura == 4:
              
              print(f"La nota de IA es:  {notaIA}");  
              
            elif opcion_Asignatura == 5:
              
               print(f"La nota de Ciencia de datos es: {notaC}");  
    
            else: print("Debes ingresar la nota primero"); 
      
      elif opcion_Asignatura == 7:
      
        print("¡Adios, que tenga buena jornada!")
        
      else: print("¡ERROR!, Selecciona la opcion 6 o 7"); 
      
# Mensaje de error en caso de elegir una opcion invalida;  
  
    except ValueError: print("¡ERRROR!, selecciona una opcion valida"); 